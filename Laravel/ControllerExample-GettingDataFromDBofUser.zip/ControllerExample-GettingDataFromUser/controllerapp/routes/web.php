<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


// Route to get all users
Route::get('/users', [UserController::class, 'index']);

// Route to get a specific user by ID
Route::get('/users/{id}', [UserController::class, 'show']);

// Route to create a new user
Route::post('/users', [UserController::class, 'store']);

// Route to update an existing user
Route::put('/users/{id}', [UserController::class, 'update']);

// Route to delete a user
Route::delete('/users/{id}', [UserController::class, 'destroy']);
<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function index()
    {
        // Get all users from the database
        $users = User::all();

        // Return the users as a response
        return response()->json($users);
    }

    public function show($id)
    {
        // Find a user by ID
        $user = User::find($id);

        // If the user doesn't exist, return an error response
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        // Return the user as a response
        return response()->json($user);
    }

    public function store(Request $request)
    {
        // Validate the request data
        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'email' => 'required|email|unique:users',
            'password' => 'required|string|min:6',
        ]);

        // If validation fails, return the error response
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        // Create a new user
        $user = new User();
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->password = bcrypt($request->input('password'));
        $user->save();

        // Return the created user as a response
        return response()->json($user, 201);
    }

    public function update(Request $request, $id)
    {
        // Find a user by ID
        $user = User::find($id);

        // If the user doesn't exist, return an error response
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        // Validate the request data
        $validator = Validator::make($request->all(), [
            'name' => 'string',
            'email' => 'email|unique:users,email,' . $id,
            'password' => 'string|min:6',
        ]);

        // If validation fails, return the error response
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        // Update the user's data
        if ($request->has('name')) {
            $user->name = $request->input('name');
        }

        if ($request->has('email')) {
            $user->email = $request->input('email');
        }

        if ($request->has('password')) {
            $user->password = bcrypt($request->input('password'));
        }

        $user->save();

        // Return the updated user as a response
        return response()->json($user);
    }

    public function destroy($id)
    {
        // Find a user by ID
        $user = User::find($id);

        // If the user doesn't exist, return an error response
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        // Delete the user
        $user->delete();

        // Return a success message
        return response()->json(['message' => 'User deleted']);
    }
}

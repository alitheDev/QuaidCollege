<!DOCTYPE html>
<html>
<head>
    <title>Create Task</title>
</head>
<body>
    <h1>Create Task</h1>

    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('tasks.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="title">Title:</label>
            <input type="text" name="title" id="title" value="<?php echo e(old('title')); ?>">
        </div>
        <div>
            <label for="description">Description:</label>
            <textarea name="description" id="description"><?php echo e(old('description')); ?></textarea>
        </div>
        <button type="submit">Create</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\Ali\Desktop\Laravel\CRUD\crud-app\resources\views/tasks/create.blade.php ENDPATH**/ ?>
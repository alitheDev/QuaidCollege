<!DOCTYPE html>
<html>
<head>
    <title>Task Manager</title>
</head>
<body>
    <h1>Task Manager</h1>

    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('tasks.create')); ?>">Create Task</a>

    <ul>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('tasks.show', $task)); ?>"><?php echo e($task->title); ?></a>
                <a href="<?php echo e(route('tasks.edit', $task)); ?>">Edit</a>
                <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" style="display:inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\Users\Ali\Desktop\Laravel\CRUD\crud-app\resources\views/tasks/index.blade.php ENDPATH**/ ?>
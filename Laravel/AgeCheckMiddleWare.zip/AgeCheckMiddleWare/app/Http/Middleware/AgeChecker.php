<?php

namespace App\Http\Middleware;

use Closure;

class AgeChecker
{
    public function handle($request, Closure $next)
    {
        $age = $request->input('age');
        $age=18;
        if ($age == 18) {
            return $next($request);
        }

        return redirect('/')->with('error', 'You must be at least 18 years old to access this page.');
    }
}

<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get("/first", "first");

Route::get('/', function () {
    return view('welcome');
});

Route::get('/viewdata', function () {
    return view('viewdata');
});

//if the user fetches 
Route::redirect('/sortdata', '/viewdata');

/*Route::get('/sortdata', function () {
    return view('sortdata');
});
*/

Route::get('/analyze', function () {
    return view('analyze');
});


//route resitriction
Route::get('/restricted', function () {
    return 'You have accessed the restricted page.';
})->middleware('age.check');





// Route::redirect('/first', '/welcome');

















